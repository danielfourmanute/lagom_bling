# Middleware Lagom DRP ↔ Bling

Scaffold novo em Node.js/TypeScript para construir um middleware auditável entre o Lagom DRP e o Bling API v3. A árvore foi criada nesta sandbox porque a cópia original não estava disponível; não é uma alteração nem uma sincronização do repositório remoto anterior.

## Estado desta entrega

Inclui monorepo pnpm, API Fastify read-only, painel Vue 3/PrimeVue, worker inerte, contratos de domínio, chave de idempotência, máquina de estados, schema Prisma, migrations e configuração Docker Compose completa para API, interface, worker, PostgreSQL e Redis. O painel não apresenta métricas de negócio fictícias.

**Nenhuma operação real de escrita foi implementada ou executada.** Scheduler e fluxos de integração estão desligados; a API recusa flags activas e o worker permanece ocioso. A transferência nativa entre depósitos no Bling continua bloqueada por falta de endpoint confirmado. Esta base não está pronta para produção.

## Executar tudo em Docker

Requisitos: Docker Engine e Docker Compose v2. Na raiz do projecto:

```bash
cp .env.example .env
docker compose config
docker compose up --build
```

O Compose constrói a imagem Node 22/pnpm, espera PostgreSQL e Redis ficarem saudáveis, aplica migrations com um serviço de execução única e depois inicia API, painel Vue e worker inerte. As portas são limitadas a `127.0.0.1`: painel `http://localhost:5173`, API `http://localhost:3000/api/health`, PostgreSQL `localhost:5432` e Redis `localhost:6379`.

Para acompanhar os serviços: `docker compose ps` e `docker compose logs -f api web worker`. Parar sem apagar dados: `docker compose down`. O banco e Redis usam volumes nomeados persistentes; **não** executar `docker compose down -v` salvo se a eliminação desses dados for pretendida.

O `.env` é usado pelo Compose apenas para interpolação local, está ignorado pelo Git e excluído do contexto Docker. Altere `POSTGRES_PASSWORD` para um valor URL-safe se necessário. Não colocar segredos de Lagom/Bling no `.env` até existirem conectores implementados e um procedimento de secret management aprovado.

## Executar sem Docker

Com Node.js 22+ e pnpm 11, é possível validar localmente:

```bash
pnpm install
pnpm db:validate
pnpm build
pnpm test
pnpm dev:api
```

Num segundo terminal, executar `pnpm dev:web`. Para aplicar migrations num PostgreSQL local já iniciado, configurar `DATABASE_URL` e executar `pnpm db:migrate:deploy`.

## Estrutura

`apps/api` contém a API Fastify e health check; `apps/worker` arranca inerte; `apps/web` contém o painel Vue/PrimeVue; `packages/domain` contém estados e idempotência; `packages/connectors` publica contratos/guardas; `packages/database` define ports de persistência; `prisma/schema.prisma` é o schema único e `prisma/migrations` é a única localização de migrations.

O mapa externo está em `docs/api-mapping.md`; lacunas em `docs/gaps.md`; arquitectura em `docs/architecture.md`; próximos passos e homologação em `docs/implementation-plan.md` e `docs/homologacao.md`.

## Limites e segurança

A única rota HTTP é `GET /api/health`. Não há operações administrativas, endpoints OAuth, reprocessamento ou sincronização real. O frontend não acede directamente a Lagom/Bling e não exibe credenciais. Não publicar fora do localhost antes de adicionar autenticação, RBAC, política CORS, monitorização e testes de segurança.
