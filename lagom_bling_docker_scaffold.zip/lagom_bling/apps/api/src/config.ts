import 'dotenv/config';
import { z } from 'zod';

const envBoolean = z.preprocess((value) => {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'string') {
    if (value.toLowerCase() === 'true') return true;
    if (value.toLowerCase() === 'false' || value === '') return false;
  }
  return value;
}, z.boolean().default(false));

const EnvironmentSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  APP_PORT: z.coerce.number().int().min(1024).max(65535).default(3000),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  LAGOM_API_BASE_URL: z.url().default('https://beta-api-sandbox.lagomtech.com.br'),
  BLING_API_BASE_URL: z.url().default('https://api.bling.com.br/Api/v3'),
  SCHEDULER_ENABLED: envBoolean,
  WRITE_ENABLED: envBoolean,
  LAGOM_TO_BLING_ENABLED: envBoolean,
  BLING_TO_LAGOM_ENABLED: envBoolean,
});

export type AppConfig = z.infer<typeof EnvironmentSchema>;

export function loadConfig(env: NodeJS.ProcessEnv = process.env): AppConfig {
  const parsed = EnvironmentSchema.parse(env);
  if (parsed.SCHEDULER_ENABLED || parsed.WRITE_ENABLED || parsed.LAGOM_TO_BLING_ENABLED || parsed.BLING_TO_LAGOM_ENABLED) {
    throw new Error('Este scaffold não implementa jobs/escritas reais; mantenha todas as flags de integração false.');
  }
  return parsed;
}
