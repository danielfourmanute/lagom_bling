import { loadConfig } from './config.js';
import { buildServer } from './server.js';

const config = loadConfig();
const app = await buildServer(config);

try {
  await app.listen({ host: '0.0.0.0', port: config.APP_PORT });
  app.log.info({ port: config.APP_PORT }, 'API iniciada; integrações externas permanecem desligadas.');
} catch (error) {
  app.log.error({ err: error }, 'Não foi possível iniciar a API.');
  process.exitCode = 1;
}

for (const signal of ['SIGINT', 'SIGTERM'] as const) {
  process.on(signal, () => {
    void app.close().finally(() => process.exit(0));
  });
}
