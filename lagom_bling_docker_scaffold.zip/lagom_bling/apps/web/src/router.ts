import { createRouter, createWebHistory } from 'vue-router';
import DashboardView from './views/DashboardView.vue';
import TransactionsView from './views/TransactionsView.vue';
import JobsView from './views/JobsView.vue';
import ConnectionsView from './views/ConnectionsView.vue';

export const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', name: 'dashboard', component: DashboardView },
    { path: '/transactions', name: 'transactions', component: TransactionsView },
    { path: '/jobs', name: 'jobs', component: JobsView },
    { path: '/connections', name: 'connections', component: ConnectionsView },
  ],
});
