<script setup lang="ts">
const connections = [
  { name: 'Lagom DRP — sandbox', status: 'Contrato confirmado', detail: 'OpenAPI beta localizado. Credenciais de homologação e respostas funcionais ainda não validadas.', tone: 'state-pending' },
  { name: 'Bling API v3', status: 'Contrato parcial confirmado', detail: 'OAuth, compras, produtos, contactos, depósitos e saldos documentados; host OAuth e scopes carecem de validação.', tone: 'state-pending' },
  { name: 'Transferência entre depósitos', status: 'Bloqueada', detail: 'Não foi encontrada operação nativa confirmada no OpenAPI Bling; não substituir por ajuste ou par de lançamentos.', tone: 'state-blocked' },
];
</script>

<template>
  <section class="page-content">
    <div class="page-heading"><div><p class="eyebrow">CONTRATOS E SAÚDE</p><h1>Conexões</h1><p class="lead">Estado documental conhecido. Nenhuma credencial ou token é exibido nesta interface.</p></div></div>
    <div class="connection-grid">
      <article v-for="connection in connections" :key="connection.name" class="connection-card">
        <div class="connection-top"><span class="status-dot" aria-hidden="true"></span><span :class="['state-pill', connection.tone]">{{ connection.status }}</span></div>
        <h2>{{ connection.name }}</h2><p>{{ connection.detail }}</p>
      </article>
    </div>
  </section>
</template>
