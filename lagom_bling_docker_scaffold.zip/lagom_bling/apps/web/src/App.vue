<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router';
</script>

<template>
  <div class="app-shell">
    <aside class="sidebar">
      <div class="brand-lockup">
        <div class="brand-mark" aria-hidden="true">L↔B</div>
        <div>
          <strong>Lagom <span>×</span> Bling</strong>
          <small>Central de integrações</small>
        </div>
      </div>

      <nav class="navigation" aria-label="Navegação principal">
        <RouterLink to="/" class="nav-link" exact-active-class="active">
          <span class="nav-symbol">01</span> Visão geral
        </RouterLink>
        <RouterLink to="/transactions" class="nav-link" active-class="active">
          <span class="nav-symbol">02</span> Transações
        </RouterLink>
        <RouterLink to="/jobs" class="nav-link" active-class="active">
          <span class="nav-symbol">03</span> Agendamentos
        </RouterLink>
        <RouterLink to="/connections" class="nav-link" active-class="active">
          <span class="nav-symbol">04</span> Conexões e contratos
        </RouterLink>
      </nav>

      <div class="sidebar-foot">
        <span class="status-dot" aria-hidden="true"></span>
        <span>Modo scaffold · escrita desligada</span>
      </div>
    </aside>

    <main class="main-area">
      <header class="topbar">
        <span class="eyebrow">MIDDLEWARE · AMBIENTE LOCAL</span>
        <span class="topbar-badge">SEM INTEGRAÇÕES ACTIVAS</span>
      </header>
      <RouterView />
    </main>
  </div>
</template>
